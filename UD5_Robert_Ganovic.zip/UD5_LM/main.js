
//he hecho con chatgpt una pool de 10 preguntas, algunas son un poco tontas, la idea es que se seleccionen 3 preguntas aleatorias entre estas 10
//hay una funcion resetQuiz() que reinicia el contador y score a 0 y selecciona otras 3.
const quizData = [
    { question: "¿Qué significa HTML?", options: ["Hyper Text Markup Language", "High Tech Modern Language", "Hyper Transfer Machine Learning"], answer: 0 },
    { question: "¿Cuál es el propósito de CSS?", options: ["Dar estilo a las páginas web", "Añadir lógica a las páginas web", "Crear bases de datos"], answer: 0 },
    { question: "¿JavaScript es un lenguaje de...?", options: ["Marcado", "Estilos", "Programación"], answer: 2 },
    { question: "¿Qué etiqueta se usa para crear un enlace en HTML?", options: ["<link>", "<a>", "<href>"], answer: 1 },
    { question: "¿Cuál de estas opciones NO es un lenguaje de programación?", options: ["Python", "HTML", "Java"], answer: 1 },
    { question: "¿Cuál es el resultado de 2 + '2' en JavaScript?", options: ["4", "22", "Error"], answer: 1 },
    { question: "¿Cómo se define una variable en JavaScript?", options: ["var x = 10;", "variable x = 10;", "let x == 10;"], answer: 0 },
    { question: "¿Qué propiedad de CSS se usa para cambiar el color de fondo?", options: ["color", "background-color", "border"], answer: 1 },
    { question: "¿Qué método de JavaScript se usa para imprimir en la consola?", options: ["console.log()", "print()", "log.console()"], answer: 0 },
    { question: "¿Qué significa CSS?", options: ["Cascading Style Sheets", "Computer Style System", "Creative Sheet Styles"], answer: 0 }
];

let score = 0;
let selectedQuestions = []; //la lista de preguntas
let selectedAnswer = null;

const questionElement = document.getElementById("question");
const optionsElement = document.getElementById("options");
const counterElement = document.getElementById("counter");

//con un rng selecciono tres preguntas
function selectRandomQuestions() {
    while (selectedQuestions.length < 3) { //hasta que no haya 3 preguntas seleccionadas
        let randomIndex = Math.floor(Math.random() * quizData.length); //del 0 al 9
        if (!selectedQuestions.includes(randomIndex)) { //sin repeticion
            selectedQuestions.push(randomIndex);
        }
    }
}

//esta funcion recibe el indice de la pregunta que cargar y genera los botones de las respuestas entre otras cosas como escribir la pregunta en cuestion al principio o el contador al final
function loadQuestion(index) {
    currentQuestionIndex = index;
    const q = quizData[selectedQuestions[index]];
    questionElement.textContent = q.question;
    optionsElement.innerHTML = "";
    selectedAnswer = null;

    q.options.forEach((option, i) => {
        const button = document.createElement("button");
        button.textContent = option;
        button.className = "block w-full p-2 mt-2 bg-gray-200 hover:bg-gray-300 rounded";

        button.onclick = function() {
            selectedAnswer = i;
            document.getElementById("nextButton").disabled = false;

            //aqui incorporo una representacion visual de los botones que selecciona el usuario
            //quitar la selección previa de todos los botones
            Array.from(optionsElement.children).forEach(btn => {
                btn.classList.remove("bg-gray-300", "hover:bg-gray-400");
                btn.classList.add("bg-gray-200", "hover:bg-gray-300");
            });

            //resaltar el botón seleccionado
            button.classList.remove("bg-gray-200", "hover:bg-gray-300");
            button.classList.add("bg-gray-300", "hover:bg-gray-400");
        };

        optionsElement.appendChild(button);
    });

    counterElement.textContent = `Pregunta ${index + 1} de 3`;
    document.getElementById("nextButton").disabled = true;
}

//funcion para comprobar la respuesta y mostrar los colores
function checkAnswer(selected, currentQuestionIndex) {
    const buttons = optionsElement.getElementsByTagName("button");
    const correctAnswer = quizData[selectedQuestions[currentQuestionIndex]].answer;

    //no he conseguido hacer esto con css, cree las clases "incorrecto" y "correcto" pero no sobreescribe las clases aunque use !important
    buttons[selected].classList.remove("bg-gray-200", "hover:bg-gray-300");
    if (selected === correctAnswer) {
        score++;
        buttons[selected].classList.add("bg-green-500");
    } else {
        buttons[selected].classList.add("bg-red-500");
    }

    buttons[selected].classList.add("transition-colors", "duration-100");

    //deshabilito todos los demas botones hasta que acabe el timeout
    Array.from(buttons).forEach(button => {
        button.disabled = true;
    });
    const resetButton = document.getElementById("resetButton");
    resetButton.disabled = true;
    resetButton.classList.add("bg-blue-300");
    nextButton.disabled = true; //se que esto es un poco redundante pero funciona ligeramente mejor si lo añado
    nextButton.classList.add("bg-blue-300");

    //delay de dos segundos para que a el usuario le de tiempo de ver si su respuesta es correcta
    setTimeout(() => {
        //habilito de nuevo el boton de reset y les pongo su bgcolor original
        Array.from(buttons).forEach(button => {
            button.disabled = false;
        });
        resetButton.disabled = false;
        resetButton.classList.remove("bg-blue-300");
        nextButton.classList.remove("bg-blue-300");

        //cargo la siguiente pregunta en caso de haberla o sin no termino el quiz
        if (currentQuestionIndex < selectedQuestions.length - 1) {
            loadQuestion(currentQuestionIndex + 1);
        } else {
            showResult();
        }
    }, 2000);
}

//funcion para mostrar el resultado final
function showResult() {
    questionElement.textContent = "¡Cuestionario terminado!";
    optionsElement.innerHTML = `<p class='text-lg font-semibold'>Tu puntuación: ${score} de 3</p>`;
    //oculto el boton de siguiente pregunta
    document.getElementById("nextButton").style.display = "none";
}

//asignada al boton "reset" que se encuentra bajo el cuestionario
function resetQuiz() {
    score = 0;
    selectedQuestions = [];
    selectRandomQuestions();
    loadQuestion(0);
    document.getElementById("nextButton").disabled = true;
    //vuelvo a activar el boton de siguiente pregunta, esto solo es apreciable si el usuario llega al final del quiz, el problema es que se muestra ENCIMA del reset cuando
    //esto ocurre, pero no se como arreglarlo
    document.getElementById("nextButton").style.display = "block";
}

//para inicializar todo al abrir la página
selectRandomQuestions();
loadQuestion(0);

document.getElementById("nextButton").addEventListener("click", function() {
    checkAnswer(selectedAnswer, currentQuestionIndex);
});